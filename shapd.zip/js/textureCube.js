//** Appears to not be in use, commenting out for now**


//var TextureCube = function(){
//	var r = "src/textures/cube/skybox/";
//	var urls = [ r + "px.jpg", r + "nx.jpg",
//				 r + "py.jpg", r + "ny.jpg",
//				 r + "pz.jpg", r + "nz.jpg" ];
				 
//	this.figure = THREE.ImageUtils.loadTextureCube( urls );
//	figure.format = THREE.RGBFormat;
//}