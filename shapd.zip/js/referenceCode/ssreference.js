		// tubeMeshBuilder.calculateDimensions('xyz', sceneWrapper.torusDefined);
		// calculateVolume(sceneWrapper.currentMesh.figure, sceneWrapper.currentMesh.figure.scale.x, sceneWrapper);
		
		// var canvas = document.createElement('canvas');
		// canvas.style.width = 250;
		// canvas.style.height = 250;
		// canvas.id = 'supnerd';
		// console.log(canvas);
		// document.body.appendChild(canvas);
		 
		// var canvMaterialsLibrary = new MaterialsLibrary();
		// var canvTubeMeshBuilder = new TubeMeshBuilder(canvMaterialsLibrary);
		
		// var canvSceneWrapper = new SceneWrapper(canvTubeMeshBuilder, canvMaterialsLibrary.textureCube);
		// var canvRenderer = new THREE.WebGLRenderer({preserveDrawingBuffer: true});

		// var canvView = new InputView(canvSceneWrapper, canvRenderer);
		
		// canvRenderer.setSize( 250,250 );
		// canvRenderer.setFaceCulling( THREE.CullFaceNone );
		// canvRenderer.autoClear = false;

		// canvView.addMeshElement(canvRenderer.domElement)
		// canvSceneWrapper.init();
		// window.open(document.getElementById('supnerd').toDataURL(), "_blank");
		 
		// document.write(canvas.toDataURL())
		// window.open(canvas, '_blank');
		//renderer.domElement.toDataURL("image/png");