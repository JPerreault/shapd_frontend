	/*
	
	Unused materials - they exist and we can order with them, but can't find any visual assets to display
	
	
	
		document.getElementById('blacktransparentplastic').onclick = function()
	{
		sceneWrapper.currentMesh['Material'] = 'Transparent resin black';
		name = 'Ultra-Smooth Black Plastic ';
		cost = '$$';
		smooth = 'High';
		img1 = 'assets/imgs/materialExamples/whiteTransparentResin_1.jpg';
		img2 = 'assets/imgs/materialExamples/whiteTransparentResin_2.jpg';
		description = 'Detail plastic is excellent at picking out fine details in pieces, while still having a sligtly unsmooth finish.';
		feeFlat = 2.50;
		feeperCM3 = 2.99;
		shipsinBizDays = 15;
		imgDesc = '';
		that.materialChange();
	}
	
	Materials available but no img's. Leaving out for V0
	
	document.getElementById('graytransparentplastic').onclick = function()
	{
		sceneWrapper.currentMesh['Material'] = 'Transparent resin gray';
		name = 'Ultra-Smooth Clear Gray Plastic ';
		cost = '$$';
		smooth = 'High';
		img1 = 'assets/imgs/materialExamples/whiteTransparentResin_1.jpg';
		img2 = 'assets/imgs/materialExamples/whiteTransparentResin_2.jpg';
		description = 'Detail plastic is excellent at picking out fine details in pieces, while still having a sligtly unsmooth finish.';
		feeFlat = 2.50;
		feeperCM3 = 2.99;
		shipsinBizDays = 15;
		imgDesc = '';
		that.materialChange();
	}
	
	document.getElementById('greentransparentplastic').onclick = function()
	{
		sceneWrapper.currentMesh['Material'] = 'Transparent resin green';
		name = 'Ultra-Smooth Clear Green Plastic ';
		cost = '$$';
		smooth = 'High';
		img1 = 'assets/imgs/materialExamples/whiteTransparentResin_1.jpg';
		img2 = 'assets/imgs/materialExamples/whiteTransparentResin_2.jpg';
		description = 'Detail plastic is excellent at picking out fine details in pieces, while still having a sligtly unsmooth finish.';
		feeFlat = 2.50;
		feeperCM3 = 2.99;
		shipsinBizDays = 15;
		imgDesc = '';
		that.materialChange();
	}
	document.getElementById('orangetransparentplastic').onclick = function()
	{
		sceneWrapper.currentMesh['Material'] = 'Transparent resin orange';
		name = 'Ultra-Smooth Clear Blue Plastic ';
		cost = '$$';
		smooth = 'High';
		img1 = 'assets/imgs/materialExamples/whiteTransparentResin_1.jpg';
		img2 = 'assets/imgs/materialExamples/whiteTransparentResin_2.jpg';
		description = 'Detail plastic is excellent at picking out fine details in pieces, while still having a sligtly unsmooth finish.';
		feeFlat = 2.50;
		feeperCM3 = 2.99;
		shipsinBizDays = 15;
		imgDesc = '';
		that.materialChange();
	}
	
	document.getElementById('browntransparentplastic').onclick = function()
	{
		sceneWrapper.currentMesh['Material'] = 'Transparent resin brown';
		name = 'Ultra-Smooth Brown Blue Plastic ';
		cost = '$$';
		smooth = 'High';
		img1 = 'assets/imgs/materialExamples/whiteTransparentResin_1.jpg';
		img2 = 'assets/imgs/materialExamples/whiteTransparentResin_2.jpg';
		description = 'Detail plastic is excellent at picking out fine details in pieces, while still having a sligtly unsmooth finish.';
		feeFlat = 2.50;
		feeperCM3 = 2.99;
		shipsinBizDays = 15;
		imgDesc = '';
		that.materialChange();
	}
	*/